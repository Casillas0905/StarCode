package Starcode.ast;

public abstract class OneDeclaration extends AST
{

}

