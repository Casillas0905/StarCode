package Starcode.ast;

public class Identifier extends Terminal
{
    public Identifier(String spelling)
    {
        this.spelling = spelling;
    }
}
