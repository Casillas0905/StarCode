package Starcode.ast;

public abstract class AST
{

}
