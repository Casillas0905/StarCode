package Starcode.ast;

public interface Visitor {
    public Object visitProgram( Program p, Object arg );
}
