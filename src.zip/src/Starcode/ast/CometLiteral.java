package Starcode.ast;

public class CometLiteral extends Terminal
{
    public CometLiteral(String spelling)
    {
        this.spelling = spelling;
    }
}
