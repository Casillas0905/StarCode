package Starcode.ast;

public abstract class Terminal extends AST
{
    public String spelling;
}
