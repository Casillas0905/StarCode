package Starcode.ast;

public class StarLiteral extends Terminal
{
    public StarLiteral(String spelling)
    {
        this.spelling = spelling;
    }
}
