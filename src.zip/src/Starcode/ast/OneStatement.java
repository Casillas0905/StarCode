package Starcode.ast;

public abstract class OneStatement extends AST
{

}
