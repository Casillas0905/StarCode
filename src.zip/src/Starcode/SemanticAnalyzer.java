package Starcode;

import Starcode.ast.SupernovaDeclaration;

import java.util.*;

class SemanticAnalyzer {
    private SymbolTable symbolTable = new SymbolTable();

    // Analyzes the program
    public void analyzeProgram(ASTNode program) {
        // Check that program scope is valid
        if (!program.isProgramScopeValid()) {
            throw new SemanticError("Program scope must begin with '{' and end with '}'.");
        }

        // Analyze declarations
        analyzeDeclarations(program.getDeclarations());

        // Analyze statements
        analyzeStatements(program.getStatements());
    }

    // Rule 1: Variables and functions must be declared before use
    private void analyzeDeclarations(List<ASTNode> declarations) {
        for (ASTNode declaration : declarations) {
            if (declaration instanceof SupernovaDeclaration) {
                SupernovaDeclaration supernovaDecl = (SupernovaDeclaration) declaration;
                checkSupernovaFunction(supernovaDecl);
            } else if (declaration instanceof StarDeclaration || declaration instanceof CometDeclaration) {
                handleBasicDeclarations(declaration);
            }
        }
    }

    // Handle variable declaration (STAR and COMET)
    private void handleBasicDeclarations(ASTNode declaration) {
        String identifier = declaration.getIdentifier();
        if (symbolTable.isDeclared(identifier)) {
            throw new SemanticError("Variable already declared: " + identifier);
        }

        // Variables must be initialized before use
        if (declaration instanceof StarDeclaration || declaration instanceof CometDeclaration) {
            if (!declaration.isInitialized()) {
                throw new SemanticError("Variable must be initialized before use: " + identifier);
            }
        }

        symbolTable.addDeclaration(identifier);
    }

    // Rule 2: Functions must be declared and checked for matching signature
    private void checkSupernovaFunction(SupernovaDeclaration declaration) {
        String functionName = declaration.getIdentifier();
        if (symbolTable.isFunctionDeclared(functionName)) {
            FunctionSymbol functionSymbol = symbolTable.lookupFunction(functionName);
            if (!functionSymbol.hasMatchingSignature(declaration)) {
                throw new SemanticError("Function signature mismatch: " + functionName);
            }
        } else {
            symbolTable.addFunction(functionName, declaration);
        }
    }

    // Rule 3: Analyze statements
    private void analyzeStatements(List<ASTNode> statements) {
        for (ASTNode statement : statements) {
            if (statement instanceof ExpressionStatement) {
                checkExpression((ExpressionStatement) statement);
            } else if (statement instanceof SupernovaStatement) {
                checkSupernovaStatement((SupernovaStatement) statement);
            } else if (statement instanceof ArrayAccessStatement) {
                checkArrayAccess((ArrayAccessStatement) statement);
            } else if (statement instanceof EclipseStatement) {
                checkEclipseStatement((EclipseStatement) statement);
            } else if (statement instanceof OrbitStatement) {
                checkOrbitStatement((OrbitStatement) statement);
            } else if (statement instanceof ShineStatement) {
                checkShineStatement((ShineStatement) statement);
            }
        }
    }

    // Rule 4: Array access should use COMETLITERAL as index and within bounds
    private void checkArrayAccess(ArrayAccessStatement statement) {
        String index = statement.getIndex();
        if (!isCometLiteral(index)) {
            throw new SemanticError("Array index must be a COMETLITERAL: " + index);
        }

        // Check that the index is within bounds (example logic for bounds checking)
        int arraySize = symbolTable.getArraySize(statement.getArrayName());
        int indexValue = Integer.parseInt(index);
        if (indexValue < 0 || indexValue >= arraySize) {
            throw new SemanticError("Array index out of bounds: " + index);
        }
    }

    // Rule 5: Expressions must end with a semicolon
    private void checkExpression(ExpressionStatement statement) {
        if (!statement.hasSemicolon()) {
            throw new SemanticError("Expression must end with a SEMICOLON.");
        }

        String operator = statement.getOperator();
        String leftType = evaluateExpression(statement.getLeftExpression());
        String rightType = evaluateExpression(statement.getRightExpression());

        if (!isValidOperation(operator, leftType, rightType)) {
            throw new SemanticError("Invalid operation: " + operator + " between " + leftType + " and " + rightType);
        }
    }

    // Check valid operations (STAR and COMET only use specific operands)
    private boolean isValidOperation(String operator, String leftType, String rightType) {
        if (leftType.equals("COMET") || rightType.equals("COMET")) {
            return operator.equals("+") || operator.equals("-") || operator.equals("*") || operator.equals("/");
        }
        return true;  // For non-COMET types
    }

    // Rule 6: ECLIPSE condition must evaluate to COMET literal
    private void checkEclipseStatement(EclipseStatement statement) {
        String condition = statement.getCondition();
        if (!isCometLiteral(condition)) {
            throw new SemanticError("ECLIPSE condition must evaluate to a COMET literal (1 for true, 0 for false).");
        }
    }

    // Rule 7: ORBIT (for loop) must use a COMET variable as the first identifier
    private void checkOrbitStatement(OrbitStatement statement) {
        String loopVar = statement.getLoopVar();
        if (!symbolTable.isDeclared(loopVar) || !symbolTable.lookupType(loopVar).equals("COMET")) {
            throw new SemanticError("The first identifier in an ORBIT (for loop) must be a declared COMET variable.");
        }
    }

    // Rule 8: Shine can only print STAR or COMET types
    private void checkShineStatement(ShineStatement statement) {
        String expressionType = evaluateExpression(statement.getExpression());
        if (!expressionType.equals("STAR") && !expressionType.equals("COMET")) {
            throw new SemanticError("SHINE statement can only print STAR or COMET expressions.");
        }
    }

    // Rule 9: STAR and COMET types must have corresponding literals for assignment
    private void checkStarCometAssignment(AssignmentStatement statement) {
        String variableType = symbolTable.lookupType(statement.getVariable());
        if (variableType.equals("STAR") && !isStarLiteral(statement.getValue())) {
            throw new SemanticError("STAR variables must be assigned a STARLITERAL value.");
        }
        if (variableType.equals("COMET") && !isCometLiteral(statement.getValue())) {
            throw new SemanticError("COMET variables must be assigned a COMETLITERAL value.");
        }
    }

    // Helper methods to check literals
    private boolean isStarLiteral(String value) {
        return value.matches("\"[a-zA-Z]\""); // STARLITERAL is a single character in quotes
    }

    private boolean isCometLiteral(String value) {
        return value.matches("\\d+"); // COMETLITERAL is numeric
    }

    private String evaluateExpression(Expression expr) {
        if (expr instanceof IdentifierExpression) {
            return symbolTable.lookupType(((IdentifierExpression) expr).getIdentifier());
        }
        return "UNKNOWN";
    }

    // Helper to check if a string is a valid COMETLITERAL
    private boolean isCometLiteral(String value) {
        try {
            Integer.parseInt(value);  // Check if it's a valid integer
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Program scope validity check (starts with { and ends with })
    private boolean isValidProgramScope(ASTNode program) {
        return program.getOpeningBrace().equals("{") && program.getClosingBrace().equals("}");
    }
}

class SymbolTable {
    private Map<String, String> variables = new HashMap<>();
    private Map<String, FunctionSymbol> functions = new HashMap<>();
    private Map<String, Integer> arraySizes = new HashMap<>();

    public boolean isDeclared(String identifier) {
        return variables.containsKey(identifier);
    }

    public void addDeclaration(String identifier) {
        variables.put(identifier, "UNKNOWN");  // Placeholder for type
    }

    public boolean isFunctionDeclared(String identifier) {
        return functions.containsKey(identifier);
    }

    public void addFunction(String identifier, SupernovaDeclaration decl) {
        functions.put(identifier, new FunctionSymbol(identifier, decl.getParameterTypes(), decl.getReturnType()));
    }

    public String lookupType(String identifier) {
        return variables.get(identifier);
    }

    public int getArraySize(String arrayName) {
        return arraySizes.getOrDefault(arrayName, -1);  // Return -1 if array not found
    }

    public void setArraySize(String arrayName, int size) {
        arraySizes.put(arrayName, size);
    }
}

class FunctionSymbol {
    private String name;
    private List<String> parameterTypes;
    private String returnType;

    public FunctionSymbol(String name, List<String> parameterTypes, String returnType) {
        this.name = name;
        this.parameterTypes = parameterTypes;
        this.returnType = returnType;
    }

    public boolean hasMatchingSignature(SupernovaDeclaration decl) {
        return decl.getParameterTypes().equals(parameterTypes) && decl.getReturnType().equals(returnType);
    }
}

class SemanticError extends RuntimeException {
    public SemanticError(String message) {
        super(message);
    }
}

